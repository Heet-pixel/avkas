# AVKAS & Co. – static website (plain HTML / CSS / JS)

```
index.html  about.html  services.html  events.html  careers.html  reach-us.html  blog.html  404.html
<service>.html      18 service pages   (e.g. auditing-and-assurance.html)
ca-*.html, jitendra-mevada.html          team bio pages
blog-*.html                              blog articles
style.css   config.js   api.js   forms.js   script.js
sitemap.xml  robots.txt
images/     ALL images and the hero video
```

## 1. Set the backend address (ONE place)
Open `config.js`. `PRODUCTION_API` is the address of your backend web service
(currently `https://avkas-backend.onrender.com`; if you later add `api.avkasco.com`, put that here).
On your own computer the site automatically uses `http://localhost:4000`.

## 2. Host on Render (Static Site)
New → Static Site → connect the repo that contains this folder.
Build Command: leave empty · Publish Directory: `.`
(If the folder sits inside a bigger repo, set Publish Directory to that folder's path.)

## 3. Run on your computer
Forms need the backend running (`npm start` in the backend folder). Do **not** double-click the HTML files –
browsers block form requests from `file://`. Use VS Code "Live Server" (right-click `index.html` → Open with Live Server)
or, in this folder: `npx serve -l 3000`.

## How the forms work
* Every page sends a quick background request to `<API>/api/wake` after it loads (never blocks the page).
* Contact / Career forms use `fetch`, show "Submitting...", retry up to 3 times if the backend is waking up,
  and send a unique `submissionId` so the backend never emails the same submission twice.
* The backend (separate folder) emails every submission to heetshah@gmail.com.

## Editing
Header and footer are repeated in every `.html` file (that keeps pages fast and SEO-friendly). To change the menu or the address,
edit it in each file (search & replace in VS Code works across the whole folder).

## When avkasco.com goes live
Search & replace `https://avkas.onrender.com` with `https://avkasco.com` across the folder (canonical links, sitemap, robots.txt).
